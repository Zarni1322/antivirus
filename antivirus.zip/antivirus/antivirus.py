import yara

def scan_file(file_path, rule_path):
    rules = yara.compile(rule_path)
    matches = rules.match(file_path)
    
    if matches:
        print(f"\nFile '{file_path}' Detect Malware : ")
        for match in matches:
            print(match)
    else:
        print(f"\nNo matches found for file '{file_path}'.")

# Usage example
file_path = input("\nEnter File path and file name \n(Eg:/home/user/Desktop/fle.txt) : ")
rule_path = "rules-master/index.yar"
scan_file(file_path, rule_path)