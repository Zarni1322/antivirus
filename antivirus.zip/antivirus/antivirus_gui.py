import tkinter as tk
from tkinter import filedialog
import yara

def browse_file():
    file_path = filedialog.askopenfilename()
    file_path_entry.delete(0, tk.END)
    file_path_entry.insert(tk.END, file_path)

def scan_file():
    file_path = file_path_entry.get()
    #rule_path = rule_path_entry.get()
    rule_path = "rules-master/index.yar"
    
    try:
        rules = yara.compile(rule_path)
        matches = rules.match(file_path)
        
        if matches:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"[ Detect Malware ]\n File Path:  {file_path}")
            for match in matches:
                result_text.insert(tk.END, match.rule + "\n")
        else:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"[ No matches found for file '{file_path}'.]")
    except yara.Error as e:
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, f"Error: {str(e)}")

# Create the main window
window = tk.Tk()
window.title("Antivirus Scanner @ Develop by Z@rn!")

# Create and position the widgets

file_path_label = tk.Label(window, text="File Path:")
file_path_label.pack()

file_path_entry = tk.Entry(window, width=100)
file_path_entry.pack()

browse_button = tk.Button(window, text="Browse", command=browse_file)
browse_button.pack()

#rule_path_label = tk.Label(window, text="Rule Path:")
#rule_path_label.pack()

#rule_path_entry = tk.Entry(window, width=50)
#rule_path_entry.pack()

scan_button = tk.Button(window, text="Scan", command=scan_file)
scan_button.pack()

result_text = tk.Text(window, height=50, width=100)
result_text.pack()

# Run the main event loop
window.mainloop()
